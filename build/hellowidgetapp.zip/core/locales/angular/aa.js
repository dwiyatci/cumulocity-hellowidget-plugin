require('./angular-locale_aa');
module.exports = 'ngLocale';
