require('./angular-locale_af');
module.exports = 'ngLocale';
